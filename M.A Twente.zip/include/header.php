<head>
	<title>MA Twente</title>
	<meta charset="UTF-8">
	<meta name="description" content="dit is het MA Twente project">
	<meta name="keywords" content="aplicatie voor MA Twente ">
	<meta name="author" content="Wesley van de Slikke,Bart Rooijakkers, Casey Kruijer">
	<meta name="viewport"content="width=device-witdth, initial-scale=1-0">
	<link rel="stylesheet" href="../css/style.css">
	<link rel="stylesheet" href="../css/navigatie.css">
</head>