<div class="topnav">
	<a href="configuraties.php">Configuratie</a>
    <a href="incidenten.php">Incidenten</a>
	<a href="gebruikers.php">Gebruikers</a>
	<a href="login.php">Login</a>
</div>

<div class="sidenav">
	<a href="configuratietoevoegen.php">Configuratie Toevoegen</a>
	<a href="gebruikertoevoegen.php">Gebruiker toevoegen</a>
	<a href="incidentmeld.php">Incident Melden</a>
	<a href="faq.php">Veel Gestelde Vragen</a>
</div>
